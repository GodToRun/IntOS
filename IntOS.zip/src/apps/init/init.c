#include "apilib.h"
#include "stdlibs.h"
#include <stdio.h>
#include <string.h>

int win;
int tip_index = 0;
char *tips[] = { "Press Shift+F2 to open Command.", "Click \"X\" to exit window.", "Use Int OS on your PC.", "Int OS is based haribote os.", "Command has simple interpreter.", "Int OS write in C.", "Int OS has many apps.", "Int OS made in korea.", "Int OS is an operating system.", -1 };
void draw_tip(struct BUTTON *sender) {
	char *text = "Did you know...";
	make_textbox8(win, 15, 90, 280, 130, COL8_FFFFFF);
	api_putstrwin(win, 40, 120, COL8_000000, strlen(text), text);
	api_putstrwin(win, 50, 160, COL8_000000, strlen(tips[tip_index]), tips[tip_index]);
	
	if (tips[tip_index+1] != -1) {
		tip_index++;
	}
	else {
		sender->enabled = 0;
		sender->draw(win, sender, 0);
	}
}
void HariMain(void)
{
	static char logo[16][16] = {
		".***************",
		".*OOOOOOOOOOOOO*",
		".*O***********O*",
		".*OOOOO***OOOOO*",
		".*OOOOO***OOOOO*",
		".*OOOOO***OOOOO*",
		".*OOOOO***OOOOO*",
		".*OOOOO***OOOOO*",
		".*OOOOO***OOOOO*",
		".*OOOOO***OOOOO*",
		".*OOOOO***OOOOO*",
		".*OOOOO***OOOOO*",
		".*O***********O*",
		".*O***********O*",
		".*OOOOOOOOOOOOO*",
		".***************"
	};
	char *buf;
	api_initmalloc();
	buf = api_malloc(400 * 300);
	win = api_openwin(buf, 400, 300, -1, "welcome");
	struct BUTTON close = make_button8(304, 240, 80, 30, api_end, "Close");
	struct BUTTON tip = make_button8(304, 180, 80, 30, draw_tip, "Next >>");
	char *text_1 = "Welcome To IntOS";
	api_putstrwin(win, 20, 40, COL8_000000, strlen(text_1), text_1);
	draw_tip(&tip);
	button_draw8(win, &close, 0);
	button_draw8(win, &tip, 0);
	int timer = api_alloctimer();
	api_inittimer(timer, 128);
	for (;;) {
		wait(5, timer);
		button_allupdate(&win);
		button_update(win, &close);
		button_update(win, &tip);
	}
	api_end();
}
