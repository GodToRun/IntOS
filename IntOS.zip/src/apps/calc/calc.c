#include "apilib.h"
#include <stdio.h>		/* sprintf */
#include <stdlibs.h>

#define INVALID		-0x7fffffff
char expression[100];
int cur_x = 0;
handle_t win;
int num;
int strtol(char *s, char **endp, int base);	/* 标准函数 <stdlib.h> */

char *skipspace(char *p);
int getnum(char **pp, int priority);
void btn_zero(void) {
	expression[cur_x] = '0';
	cur_x++;
	make_textbox8(win, 20, 40, 230, 30, COL8_FFFFFF);
	api_putstrwin(win, 30, 46, COL8_000000, strlen(expression), expression);
}
void btn_one(void) {
	expression[cur_x] = '1';
	cur_x++;
	make_textbox8(win, 20, 40, 230, 30, COL8_FFFFFF);
	api_putstrwin(win, 30, 46, COL8_000000, strlen(expression), expression);
}
void btn_two(void) {
	expression[cur_x] = '2';
	cur_x++;
	make_textbox8(win, 20, 40, 230, 30, COL8_FFFFFF);
	api_putstrwin(win, 30, 46, COL8_000000, strlen(expression), expression);
}
void btn_three(void) {
	expression[cur_x] = '3';
	cur_x++;
	make_textbox8(win, 20, 40, 230, 30, COL8_FFFFFF);
	api_putstrwin(win, 30, 46, COL8_000000, strlen(expression), expression);
}
void btn_four(void) {
	expression[cur_x] = '4';
	cur_x++;
	make_textbox8(win, 20, 40, 230, 30, COL8_FFFFFF);
	api_putstrwin(win, 30, 46, COL8_000000, strlen(expression), expression);
}
void btn_five(void) {
	expression[cur_x] = '5';
	cur_x++;
	make_textbox8(win, 20, 40, 230, 30, COL8_FFFFFF);
	api_putstrwin(win, 30, 46, COL8_000000, strlen(expression), expression);
}
void btn_six(void) {
	expression[cur_x] = '6';
	cur_x++;
	make_textbox8(win, 20, 40, 230, 30, COL8_FFFFFF);
	api_putstrwin(win, 30, 46, COL8_000000, strlen(expression), expression);
}
void btn_seven(void) {
	expression[cur_x] = '7';
	cur_x++;
	make_textbox8(win, 20, 40, 230, 30, COL8_FFFFFF);
	api_putstrwin(win, 30, 46, COL8_000000, strlen(expression), expression);
}
void btn_eight(void) {
	expression[cur_x] = '8';
	cur_x++;
	make_textbox8(win, 20, 40, 230, 30, COL8_FFFFFF);
	api_putstrwin(win, 30, 46, COL8_000000, strlen(expression), expression);
}
void btn_nine(void) {
	expression[cur_x] = '9';
	cur_x++;
	make_textbox8(win, 20, 40, 230, 30, COL8_FFFFFF);
	api_putstrwin(win, 30, 46, COL8_000000, strlen(expression), expression);
}
void btn_plus(void) {
	expression[cur_x] = '+';
	cur_x++;
	make_textbox8(win, 20, 40, 230, 30, COL8_FFFFFF);
	api_putstrwin(win, 30, 46, COL8_000000, strlen(expression), expression);
}
void btn_mul(void) {
	expression[cur_x] = '*';
	cur_x++;
	make_textbox8(win, 20, 40, 230, 30, COL8_FFFFFF);
	api_putstrwin(win, 30, 46, COL8_000000, strlen(expression), expression);
}
void btn_pct(void) {
	expression[cur_x] = '%';
	cur_x++;
	make_textbox8(win, 20, 40, 230, 30, COL8_FFFFFF);
	api_putstrwin(win, 30, 46, COL8_000000, strlen(expression), expression);
}
void btn_div(void) {
	expression[cur_x] = '/';
	cur_x++;
	make_textbox8(win, 20, 40, 230, 30, COL8_FFFFFF);
	api_putstrwin(win, 30, 46, COL8_000000, strlen(expression), expression);
}
void btn_og(void) {
	expression[cur_x] = '(';
	cur_x++;
	make_textbox8(win, 20, 40, 230, 30, COL8_FFFFFF);
	api_putstrwin(win, 30, 46, COL8_000000, strlen(expression), expression);
}
void btn_and(void) {
	expression[cur_x] = '&';
	cur_x++;
	make_textbox8(win, 20, 40, 230, 30, COL8_FFFFFF);
	api_putstrwin(win, 30, 46, COL8_000000, strlen(expression), expression);
}
void btn_xor(void) {
	expression[cur_x] = '^';
	cur_x++;
	make_textbox8(win, 20, 40, 230, 30, COL8_FFFFFF);
	api_putstrwin(win, 30, 46, COL8_000000, strlen(expression), expression);
}
void btn_or(void) {
	expression[cur_x] = '|';
	cur_x++;
	make_textbox8(win, 20, 40, 230, 30, COL8_FFFFFF);
	api_putstrwin(win, 30, 46, COL8_000000, strlen(expression), expression);
}
void btn_not(void) {
	expression[cur_x] = '~';
	cur_x++;
	make_textbox8(win, 20, 40, 230, 30, COL8_FFFFFF);
	api_putstrwin(win, 30, 46, COL8_000000, strlen(expression), expression);
}
void btn_cg(void) {
	expression[cur_x] = ')';
	cur_x++;
	make_textbox8(win, 20, 40, 230, 30, COL8_FFFFFF);
	api_putstrwin(win, 30, 46, COL8_000000, strlen(expression), expression);
}
void btn_lshft(void) {
	expression[cur_x] = '<';
	expression[cur_x+1] = '<';
	expression[cur_x+2] = 0;
	cur_x += 2;
	make_textbox8(win, 20, 40, 230, 30, COL8_FFFFFF);
	api_putstrwin(win, 30, 46, COL8_000000, strlen(expression), expression);
}
void btn_rshft(void) {
	expression[cur_x] = '>';
	expression[cur_x+1] = '>';
	expression[cur_x+2] = 0;
	cur_x += 2;
	make_textbox8(win, 20, 40, 230, 30, COL8_FFFFFF);
	api_putstrwin(win, 30, 46, COL8_000000, strlen(expression), expression);
}
void btn_minus(void) {
	expression[cur_x] = '-';
	cur_x++;
	make_textbox8(win, 20, 40, 230, 30, COL8_FFFFFF);
	api_putstrwin(win, 30, 46, COL8_000000, strlen(expression), expression);
}
void btn_equal(void) {
	char *_p = expression;
	int _i;
	num = getnum(&_p, 9);
		for (_i = 0; _i < cur_x; _i++) {
		expression[_i] = 0;
	}
	cur_x = 0;
	sprintf(expression, "%d", num);
	cur_x = strlen(expression);
	make_textbox8(win, 20, 40, 230, 30, COL8_FFFFFF);
	if (num != INVALID)
		api_putstrwin(win, 30, 46, COL8_000000, strlen(expression), expression);
	else {
		api_putstrwin(win, 30, 46, 1, 5, "ERROR");
		for (_i = 0; _i < cur_x; _i++) {
			expression[_i] = 0;
		}
		cur_x = 0;
	}
}
void btn_backspace(void) {
	cur_x--;
	expression[cur_x] = 0;
	make_textbox8(win, 20, 40, 230, 30, COL8_FFFFFF);
	api_putstrwin(win, 30, 46, COL8_000000, strlen(expression), expression);
}
void btn_clear(void) {
	int _i;
	for (_i = 0; _i < cur_x; _i++) {
		expression[_i] = 0;
	}
	cur_x = 0;
	make_textbox8(win, 20, 40, 230, 30, COL8_FFFFFF);
	api_putstrwin(win, 30, 46, COL8_000000, strlen(expression), expression);
}
void HariMain(void)
{
	char *buf;
	api_initmalloc();
	//expression = api_malloc(sizeof(char) * 100);
	static char icon[16][16] = {
		".***************",
		".*OOOOOOOOOOOOO*",
		".*OOOOOOOOOOOOO*",
		".*OO*********OO*",
		".*OO*********OO*",
		".*OOOOOOOOOOOOO*",
		".*OOOOOOOOOOOOO*",
		".*OO*OO*OO****O*",
		".*OOOOOOOOOOOOO*",
		".*OO*OO*OO*OO*O*",
		".*OOOOOOOOOOOOO*",
		".*OO*OO*OO*OO*O*",
		".*OOOOOOOOOOOOO*",
		".*OO*OO*OO*OO*O*",
		".*OOOOOOOOOOOOO*",
		".***************"
	};
	buf = api_malloc(270 * 290);
	win = api_openiconwin(&icon, buf, 270, 290, -1, "calc");
	int i;
	char *s, *p;
	//api_cmdline(s, 30);
	make_textbox8(win, 20, 40, 230, 30, COL8_FFFFFF);
	struct BUTTON zero = make_button_draw8(win, 20, 210, 30, 30, btn_zero, "0", BLUE);
	struct BUTTON one = make_button_draw8(win, 20, 170, 30, 30, btn_one, "1", BLUE);
	struct BUTTON two = make_button_draw8(win, 60, 170, 30, 30, btn_two, "2", BLUE);
	struct BUTTON three = make_button_draw8(win, 100, 170, 30, 30, btn_three, "3", BLUE);
	struct BUTTON four = make_button_draw8(win, 20, 130, 30, 30, btn_four, "4", BLUE);
	struct BUTTON five = make_button_draw8(win, 60, 130, 30, 30, btn_five, "5", BLUE);
	struct BUTTON six = make_button_draw8(win, 100, 130, 30, 30, btn_six, "6", BLUE);
	struct BUTTON seven = make_button_draw8(win, 20, 90, 30, 30, btn_seven, "7", BLUE);
	struct BUTTON eight = make_button_draw8(win, 60, 90, 30, 30, btn_eight, "8", BLUE);
	struct BUTTON nine = make_button_draw8(win, 100, 90, 30, 30, btn_nine, "9", BLUE);
	struct BUTTON backspace = make_button_draw8(win, 140, 90, 110, 30, btn_backspace, "Backspace", DARKRED);
	struct BUTTON clear = make_button_draw8(win, 140, 130, 30, 30, btn_clear, "C", DARKRED);
	struct BUTTON CE = make_button_draw8(win, 180, 130, 30, 30, btn_clear, "CE", DARKRED);
	struct BUTTON equal = make_button_draw8(win, 220, 210, 30, 30, btn_equal, "=", RED);
	struct BUTTON plus = make_button_draw8(win, 140, 210, 30, 30, btn_plus, "+", RED);
	struct BUTTON minus = make_button_draw8(win, 140, 170, 30, 30, btn_minus, "-", RED);
	struct BUTTON mul = make_button_draw8(win, 180, 170, 30, 30, btn_mul, "*", RED);
	struct BUTTON div = make_button_draw8(win, 180, 210, 30, 30, btn_div, "/", RED);
	struct BUTTON og = make_button_draw8(win, 60, 210, 30, 30, btn_og, "(", RED);
	struct BUTTON cg = make_button_draw8(win, 100, 210, 30, 30, btn_cg, ")", RED);
	struct BUTTON rshft = make_button_draw8(win, 220, 130, 30, 30, btn_rshft, ">>", DARKGREEN);
	struct BUTTON lshft = make_button_draw8(win, 220, 170, 30, 30, btn_lshft, "<<", DARKGREEN);
	struct BUTTON and = make_button_draw8(win, 20, 250, 50, 30, btn_and, "AND", DARKGREEN);
	struct BUTTON or = make_button_draw8(win, 80, 250, 50, 30, btn_or, "OR", DARKGREEN);
	struct BUTTON xor = make_button_draw8(win, 140, 250, 50, 30, btn_xor, "XOR", DARKGREEN);
	struct BUTTON not = make_button_draw8(win, 200, 250, 50, 30, btn_not, "NOT", DARKGREEN);
	int timer = api_alloctimer();
	api_inittimer(timer, 128);
	for (;;) {
		wait(5, timer);
		button_allupdate(&win);
		button_update(win, &one);
		button_update(win, &two);
		button_update(win, &zero);
		button_update(win, &three);
		button_update(win, &four);
		button_update(win, &five);
		button_update(win, &six);
		button_update(win, &seven);
		button_update(win, &eight);
		button_update(win, &nine);
		button_update(win, &backspace);
		button_update(win, &clear);
		button_update(win, &equal);
		button_update(win, &plus);
		button_update(win, &minus);
		button_update(win, &mul);
		button_update(win, &div);
		button_update(win, &og);
		button_update(win, &cg);
		button_update(win, &lshft);
		button_update(win, &rshft);
		button_update(win, &CE);
		button_update(win, &xor);
		button_update(win, &and);
		button_update(win, &or);
		button_update(win, &not);
	}
	api_end();
}

char *skipspace(char *p)
{
	for (; *p == ' '; p++) { }	/* 将空格跳过去 */
	return p;
}

int getnum(char **pp, int priority)
{
	char *p = *pp;
	int i = INVALID, j;
	p = skipspace(p);

	/*单项运算符*/
	if (*p == '+') {
		p = skipspace(p + 1);
		i = getnum(&p, 0);
	} else if (*p == '-') {
		p = skipspace(p + 1);
		i = getnum(&p, 0);
		if (i != INVALID) {
			i = - i;
		}
	} else if (*p == '~') {
		p = skipspace(p + 1);
		i = getnum(&p, 0);
		if (i != INVALID) {
			i = ~i;
		}
	} else if (*p == '(') { /*括号*/
		p = skipspace(p + 1);
		i = getnum(&p, 9);
		if (*p == ')') {
			p = skipspace(p + 1);
		} else {
			i = INVALID;
		}
	} else if ('0' <= *p && *p <= '9') { /*数值*/
		i = strtol(p, &p, 0);
	} else { /*错误 */
		i = INVALID;
	}

	/*二项运算符*/
	for (;;) {
		if (i == INVALID) {
			break;
		}
		p = skipspace(p);
		if (*p == '+' && priority > 2) {
			p = skipspace(p + 1);
			j = getnum(&p, 2);
			if (j != INVALID) {
				i += j;
			} else {
				i = INVALID;
			}
		} else if (*p == '-' && priority > 2) {
			p = skipspace(p + 1);
			j = getnum(&p, 2);
			if (j != INVALID) {
				i -= j;
			} else {
				i = INVALID;
			}
		} else if (*p == '*' && priority > 1) {
			p = skipspace(p + 1);
			j = getnum(&p, 1);
			if (j != INVALID) {
				i *= j;
			} else {
				i = INVALID;
			}
		} else if (*p == '/' && priority > 1) {
			p = skipspace(p + 1);
			j = getnum(&p, 1);
			if (j != INVALID && j != 0) {
				i /= j;
			} else {
				i = INVALID;
			}
		} else if (*p == '%' && priority > 1) {
			p = skipspace(p + 1);
			j = getnum(&p, 1);
			if (j != INVALID && j != 0) {
				i %= j;
			} else {
				i = INVALID;
			}
		} else if (*p == '<' && p[1] == '<' && priority > 3) {
			p = skipspace(p + 2);
			j = getnum(&p, 3);
			if (j != INVALID && j != 0) {
				i <<= j;
			} else {
				i = INVALID;
			}
		} else if (*p == '>' && p[1] == '>' && priority > 3) {
			p = skipspace(p + 2);
			j = getnum(&p, 3);
			if (j != INVALID && j != 0) {
				i >>= j;
			} else {
				i = INVALID;
			}
		} else if (*p == '&' && priority > 4) {
			p = skipspace(p + 1);
			j = getnum(&p, 4);
			if (j != INVALID) {
				i &= j;
			} else {
				i = INVALID;
			}
		} else if (*p == '^' && priority > 5) {
			p = skipspace(p + 1);
			j = getnum(&p, 5);
			if (j != INVALID) {
				i ^= j;
			} else {
				i = INVALID;
			}
		} else if (*p == '|' && priority > 6) {
			p = skipspace(p + 1);
			j = getnum(&p, 6);
			if (j != INVALID) {
				i |= j;
			} else {
				i = INVALID;
			}
		} else {
			break;
		}
	}
	p = skipspace(p);
	*pp = p;
	return i;
}
