#include "apilib.h"
#include "stdlibs.h"
#include <stdio.h>

void HariMain(void)
{
	char *buf;
	int win;
	api_initmalloc();
	buf = api_malloc(301 * 231);
	//win = api_openwin(buf, 301, 231, -1, "tedit");
	static char icon[16][16] = {
		".***************",
		".*OOOOOOOOOOOOO*",
		".*OOOOOOOOOOOOO*",
		".*OOOOOOOOOOOOO*",
		".*OOOOOOOOOOOOO*",
		".*OOOOOOOOOOOOO*",
		".*OOOOOOOOOOOOO*",
		".*OOOOOOOO**OOO*",
		".*OOOOOOOO**OOO*",
		".*OOOOOOO**OOOO*",
		".*OOOOOOO**OOOO*",
		".*OOOOOO**OOOOO*",
		".*OOOOOOOOOOOOO*",
		".*O***********O*",
		".*OOOOOOOOOOOOO*",
		".***************"
	};
	win = api_openiconwin(icon, buf, 301, 231, -1, "tedit");
	make_textbox8(win, 8, 30, 283, 190, COL8_FFFFFF);
	textbox_input(win, 8, 33, 277, 185, COL8_FFFFFF);
	api_end();
}
