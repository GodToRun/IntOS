#include "apilib.h"
void HariMain(void) {
	api_putstr0("hello world");
	api_end();
}
