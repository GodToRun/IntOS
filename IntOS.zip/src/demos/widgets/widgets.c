#include "apilib.h"
#include "stdlibs.h"
#include <stdio.h>
void test(void) {
	printf("HELLO WORLD");
}
void HariMain(void)
{
	char *buf;
	handle_t win;

	api_initmalloc();
	buf = api_malloc(200 * 250);
	win = api_openwin(buf, 200, 250, -1, "widgets");
	make_textbox8(win, 10, 30, 150, 50, COL8_FFFFFF);
	make_status_bar8(win, 10, 220, 100, 20, "status bar");
	make_gagebar8(win, 10, 100, 50);
	//textbox_input(win, 8, 33, 145, 45, COL8_FFFFFF);
	struct BUTTON btn = make_button8(15, 150, 85, 30, NULL, "disabled");
	btn.enabled = 0;
	struct BUTTON btn2 = make_button8(120, 150, 60, 30, test, "test");
	button_draw8(win, &btn, 0);
	button_draw8(win, &btn2, 1);
	int timer = api_alloctimer();
	api_inittimer(timer, 128);
	for (;;) {
		wait(5, timer);
		button_allupdate(&win);
		button_update(win, &btn);
		button_update(win, &btn2);
	}
	api_end();
}