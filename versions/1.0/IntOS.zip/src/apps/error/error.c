#include <string.h>
#include "apilib.h"
#include <stdlibs.h>
void HariMain(void)
{
	char *buf;
	int win, i, x, y;
	char s[50];
	char *msg;
	api_initmalloc();
	api_cmdline(s, 50);
	msg = &s[6];
	buf = api_malloc(300 * 110);
	win = api_openwin(buf, 300, 110, -1, "error");
	struct BUTTON ok = make_button8(120, 70, 70, 25, api_end, "OK");
	api_putstrwin(win, 20, 40, COL8_000000, strlen(msg), msg);
	button_draw8(win, &ok, 1);
	int timer = api_alloctimer();
	api_inittimer(timer, 128);
	for (;;) {
		wait(5, timer);
		button_allupdate(&win);
		button_update(win, &ok);
	}	
	api_closewin(win);
	api_end();
}
