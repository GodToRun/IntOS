#include "apilib.h"
#include <stdlibs.h>
#include <string.h>
#include <stdio.h>
handle_t win;
int cur_c = 0;
void set_color_black(struct BUTTON *btn) {
	cur_c = COL8_000000;
}
void set_color_white(struct BUTTON *btn) {
	cur_c = COL8_FFFFFF;
}
void set_color_red(struct BUTTON *btn) {
	cur_c = 1;
}
void mktxtbox(void) {
	make_textbox8(win, 20, 40, 270, 210, COL8_FFFFFF);
}
void draw_white_btn(const handle_t win, const struct BUTTON *sender) {
	make_textbox8(win, sender->x, sender->y, sender->width, sender->height, COL8_FFFFFF);
	draw_palatte();
}
void draw_black_btn(const handle_t win, const struct BUTTON *sender) {
	make_textbox8(win, sender->x, sender->y, sender->width, sender->height, COL8_000000);
	draw_palatte();
}
void draw_red_btn(const handle_t win, const struct BUTTON *sender) {
	make_textbox8(win, sender->x, sender->y, sender->width, sender->height, 1);
	draw_palatte();
}
void draw_palatte() {
	make_textbox8(win, 20, 260, 30, 30, COL8_FFFFFF);
	api_boxfilwin(win, 24, 264, 46, 286, COL8_000000);
	api_boxfilwin(win, 25, 265, 45, 285, cur_c);
}
void HariMain(void)
{
	api_initmalloc();
	char *buf = api_malloc(310 * 300);
	win = api_openwin(buf, 310, 300, -1, "paint");
	struct BUTTON btn = make_button8(70, 265, 20, 20, set_color_black, "black");
	struct BUTTON btn2 = make_button8(100, 265, 20, 20, set_color_white, "white");
	struct BUTTON btny = make_button8(130, 265, 20, 20, set_color_red, "red");
	struct BUTTON btn3 = make_button8(203, 260, 80, 30, mktxtbox, "clear");
	btn2.draw = draw_white_btn;
	btn2.pressed_draw = draw_white_btn;
	btn.draw = draw_black_btn;
	btn.pressed_draw = draw_black_btn;
	btny.draw = draw_red_btn;
	btny.pressed_draw = draw_red_btn;
	mktxtbox();
	button_draw8(win, &btn, 0);
	button_draw8(win, &btn2, 0);
	button_draw8(win, &btn3, 0);
	button_draw8(win, &btny, 0);
	int timer = api_alloctimer();
	api_inittimer(timer, 128);
	for (;;) {
		wait(5, timer);
		button_allupdate(&win);
		if (api_is_leftclicked(win)) {
			int wmx, wmy;
			wmx = api_get_wmx(win);
			wmy = api_get_wmy(win);
			if (wmx > 20 && wmy > 40 && wmx < 290 && wmy < 250) {
				draw_point(win, wmx, wmy);
			}
		}
		button_update(win, &btn);
		button_update(win, &btn2);
		button_update(win, &btn3);
		button_update(win, &btny);
	}
	api_closewin(win);
	api_end();
}
void draw_point(handle_t win, int wmx, int wmy) {
	api_boxfilwin(win, wmx, wmy, wmx+1, wmy+1, cur_c);
}