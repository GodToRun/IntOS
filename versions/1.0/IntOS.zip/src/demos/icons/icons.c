#include "apilib.h"
#include "stdlibs.h"
#include <stdio.h>

void HariMain(void)
{
	char *buf;
	int win;
	static char cursor[16][16] = {
		"**************..",
		"*OOOOOOOOOOO*...",
		"*OOOOOOOOOO*....",
		"*OOOOOOOOO*.....",
		"*OOOOOOOO*......",
		"*OOOOOOO*.......",
		"*OOOOOOO*.......",
		"*OOOOOOOO*......",
		"*OOOO**OOO*.....",
		"*OOO*..*OOO*....",
		"*OO*....*OOO*...",
		"*O*......*OOO*..",
		"**........*OOO*.",
		"*..........*OOO*",
		"............*OO*",
		".............***"
	};
	api_initmalloc();
	buf = api_malloc(301 * 60);
	win = api_openwin(buf, 301, 60, -1, "icons");
	make_textbox8(win, 8, 30, 283, 20, COL8_FFFFFF);
	draw_bitmap(win, 16, 16, &cursor, 12, 33, 1);
	for (;;) {
		int key = api_getkey(1);
		if (key == 0x0a)
			break;
	}
	api_end();
}
