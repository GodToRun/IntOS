#include "apilib.h"
#include <stdio.h>

void HariMain(void)
{
	char *buf;
	int win, mx, my;
	char *text;
	api_initmalloc();
	buf = api_malloc(150 * 50);
	win = api_openwin(buf, 150, 50, -1, "winhelo3");
	for (;;) {
		
	}
	api_end();
}
