#ifndef STDLIBS_H
#define STDLIBS_H
#define main HariMain
#define IntMain HariMain
#define COL8_000000		0
#define COL8_FF0000		1
#define COL8_00FF00		2
#define COL8_FFFF00		3
#define COL8_0000FF		4
#define COL8_FF00FF		5
#define COL8_00FFFF		6
#define COL8_FFFFFF		7
#define COL8_C6C6C6		8
#define COL8_840000		9
#define COL8_008400		10
#define COL8_848400		11
#define COL8_000084		12
#define COL8_840084		13
#define COL8_008484		14
#define COL8_848484		15
#ifndef NCOLDEF
#define BLACK       COL8_000000
#define WHITE       COL8_FFFFFF
#define RED         COL8_FF0000
#define LIME        COL8_00FF00
#define YELLOW      COL8_FFFF00
#define BLUE        COL8_0000FF
#define MAGENTA     COL8_FF00FF
#define MINT        COL8_00FFFF
#define LIGHTGRAY   COL8_C6C6C6
#define DARKRED     COL8_840000
#define DARKGREEN   COL8_008400
#define DARKYELLOW  COL8_848400
#define DARKBLUE    COL8_000084
#define DARKMAGENTA COL8_840084
#define CYAN        COL8_008484
#define DARKGRAY    COL8_848484
#endif

typedef unsigned int uint32_t;
typedef unsigned short uint16_t;
typedef unsigned char uint8_t;

typedef signed int int32_t;
typedef signed short int16_t;
typedef int32_t handle_t;
typedef signed char int8_t;

struct BUTTON {
    int x, y;
    int width, height;
    int fcol;
    char *text;
    char enabled;
    char clicked;
    void (*event)(struct BUTTON *sender);
    void (*draw)(const handle_t win, const struct BUTTON *sender, char selected);
    void (*pressed_draw)(const handle_t win, const struct BUTTON *sender);
};

typedef struct HWND {
    int xsize, ysize;
    handle_t handle;
    char *buf, title;
} HWND;
HWND *create_win(int size_x, int size_y, char *title);
int putchar(int c);
void exit(int status);
int printf(char *format, ...);
void *malloc(int size);
int scanf(char * str, ...);
int wait(int i, int timer);
struct BUTTON make_button_draw8(handle_t win, int x, int y, int width, int height, int *event, char *text, int fcol);
int strtol(char *s, char **endp, int base);
void make_textbox8(int win, int x0, int y0, int sx, int sy, int c);
void make_status_bar8(int win, int x0, int y0, int sx, int sy, char *status);
void textbox_input(int win, int x, int y, int sx, int sy, int col);
void draw_bitmap(int win, int xsize, int ysize, char bitmap[xsize][ysize], int bx, int by, int width);
void make_gagebar8(handle_t win, int x, int y, int percentage);
struct BUTTON make_button8(int x, int y, int width, int height, int *event, char *text);
void button_draw8(handle_t win, const struct BUTTON *btn, char selected);
void link_draw8(handle_t win, struct BUTTON *btn);
void button_update(handle_t win, struct BUTTON *btn);
void link_update(handle_t win, struct BUTTON *btn);
void button_allupdate(handle_t *win);
#endif