/* copyright(C) 2021 RunToRun */

#include <stdlibs.h>
#include <stdbool.h>

#ifndef ASSERT_H
#define ASSERT_H
#ifndef NDEBUG
void assert(_Bool statement);
void assert(_Bool statement) {
    if (!statement)
        printf("Assertion failed.");
}
#endif


#endif