#include "apilib.h"
#include "stdlibs.h"

#include <stdio.h>
#include <stdarg.h>
#include <string.h>

#ifdef LIBC
#define main HariMain
#define puts api_putstr0
#define getch() api_getkey(0)
#endif

int mx, my, clicked, is_active;
struct CHECKBOX *cur_chkbox;

int putchar(int c)
{
	api_putchar(c);
	return c;
}

void exit(int status)
{
	api_end();
}
void make_textbox8(int win, int x0, int y0, int sx, int sy, int c)
{
	int x1 = x0 + sx, y1 = y0 + sy;
	api_boxfilwin(win, x0 - 2, y0 - 3, x1 + 1, y0 - 3, COL8_848484);
	api_boxfilwin(win, x0 - 3, y0 - 3, x0 - 3, y1 + 1, COL8_848484);
	api_boxfilwin(win, x0 - 3, y1 + 2, x1 + 1, y1 + 2, COL8_FFFFFF);
	api_boxfilwin(win, x1 + 2, y0 - 3, x1 + 2, y1 + 2, COL8_FFFFFF);
	api_boxfilwin(win, x0 - 1, y0 - 2, x1 + 0, y0 - 2, COL8_000000);
	api_boxfilwin(win, x0 - 2, y0 - 2, x0 - 2, y1 + 0, COL8_000000);
	api_boxfilwin(win, x0 - 2, y1 + 1, x1 + 0, y1 + 1, COL8_C6C6C6);
	api_boxfilwin(win, x1 + 1, y0 - 2, x1 + 1, y1 + 1, COL8_C6C6C6);
	api_boxfilwin(win,           x0 - 1, y0 - 1, x1 + 0, y1 + 0, c);
	return;
}
void make_status_bar8(int win, int x0, int y0, int sx, int sy, char *status)
{
	int x1 = x0 + sx, y1 = y0 + sy;
	api_boxfilwin(win, x0 - 2, y0 - 3, x1 + 1, y0 - 3, COL8_848484);
	api_boxfilwin(win, x0 - 3, y0 - 3, x0 - 3, y1 + 1, COL8_848484);
	api_boxfilwin(win, x0 - 3, y1 + 2, x1 + 1, y1 + 2, COL8_FFFFFF);
	api_boxfilwin(win, x1 + 2, y0 - 3, x1 + 2, y1 + 2, COL8_FFFFFF);
	//api_boxfilwin(win, x0 - 1, y0 - 2, x1 + 0, y0 - 2, COL8_000000);
	//api_boxfilwin(win, x0 - 2, y0 - 2, x0 - 2, y1 + 0, COL8_000000);
	api_boxfilwin(win, x0 - 2, y1 + 1, x1 + 0, y1 + 1, COL8_C6C6C6);
	api_boxfilwin(win, x1 + 1, y0 - 2, x1 + 1, y1 + 1, COL8_C6C6C6);
	api_boxfilwin(win,           x0 - 1, y0 - 1, x1 + 0, y1 + 0, COL8_C6C6C6);
	api_putstrwin(win, x0, y0 + 3, COL8_000000, strlen(status), status);
	return;
} 
void draw_bitmap(int win, int xsize, int ysize, char bitmap[xsize][ysize], int bx, int by, int width) {
	int x, y, i;
	for (y = 0; y < ysize; y++) {
		for (x = 0; x < xsize; x++) {
			for (i = 0; i < width; i++) {
				if (bitmap[y][x] == '.') {
					continue;
				}
				else {
					api_point(win, bx + x + i, by + y + i, api_decode_color((int)bitmap[y][x]));
				}
			}
		}
	}
}
HWND *create_win(int size_x, int size_y, char *title) {
	HWND hwnd;
	hwnd.buf = api_malloc(size_x * size_y);
	hwnd.title = title;
	hwnd.xsize = size_x;
	hwnd.ysize = size_y;
	hwnd.handle = api_openwin(hwnd.buf, size_x, size_y, -1, title);
	return &hwnd;
}
void button_drawprs(const handle_t win, const struct BUTTON *btn) {
	api_boxfilwin(win, btn->x-1, btn->y-1, btn->x+btn->width+1, btn->y+btn->height+1, COL8_000000);
	api_boxfilwin(win, btn->x, btn->y+btn->height-1, btn->x+btn->width, btn->y+btn->height, COL8_848484);
	api_boxfilwin(win, btn->x+btn->width-1, btn->y, btn->x+btn->width, btn->y+btn->height, COL8_848484);
	api_boxfilwin(win, btn->x, btn->y, btn->x+1, btn->y+btn->height, COL8_848484);
	api_boxfilwin(win, btn->x, btn->y, btn->x+btn->width, btn->y+1, COL8_848484);
	api_boxfilwin(win, btn->x+2, btn->y+2, btn->x+btn->width-2, btn->y+btn->height-2, COL8_C6C6C6);
	api_putstrwin(win, btn->x+((btn->width-(strlen(btn->text)*4))/3)+2, btn->y+(btn->height/3), btn->fcol,
	strlen(btn->text), btn->text);
}
void button_drawbtn(const handle_t win, const struct BUTTON *btn, char selected) {
	if (selected) {
		api_boxfilwin(win, btn->x-2, btn->y-2, btn->x+btn->width+2, btn->y+btn->height+2, COL8_000000);
	}
	api_boxfilwin(win, btn->x-1, btn->y-1, btn->x+btn->width+1, btn->y+btn->height+1, COL8_000000);
	api_boxfilwin(win, btn->x, btn->y+btn->height-2, btn->x+btn->width, btn->y+btn->height, COL8_848484);
	api_boxfilwin(win, btn->x+btn->width-2, btn->y, btn->x+btn->width, btn->y+btn->height, COL8_848484);
	api_boxfilwin(win, btn->x, btn->y, btn->x+2, btn->y+btn->height, COL8_FFFFFF);
	api_boxfilwin(win, btn->x, btn->y, btn->x+btn->width, btn->y+2, COL8_FFFFFF);
	api_boxfilwin(win, btn->x+3, btn->y+3, btn->x+btn->width-3, btn->y+btn->height-3, COL8_C6C6C6);
	if (btn->enabled)
		api_putstrwin(win, btn->x+((btn->width-(strlen(btn->text)*4))/3)-1, btn->y+(btn->height/3)-1, btn->fcol,
		strlen(btn->text), btn->text);
	else {
		api_putstrwin(win, btn->x+((btn->width-(strlen(btn->text)*4))/3)-2, btn->y+(btn->height/3), COL8_FFFFFF,
		strlen(btn->text), btn->text);
		api_putstrwin(win, btn->x+((btn->width-(strlen(btn->text)*4))/3)-1, btn->y+(btn->height/3)-1, COL8_848484,
		strlen(btn->text), btn->text);
	}
	return;
}
struct BUTTON make_button8(int x, int y, int width, int height, int *event, char *text) {
	struct BUTTON btn;
	btn.x = x;
	btn.text = text;
	btn.enabled = !0;
	btn.fcol = COL8_000000;
	btn.y = y;
	btn.width = width;
	btn.height = height;
	btn.clicked = 0;
	btn.draw = button_drawbtn;
	btn.pressed_draw = button_drawprs;
	btn.event = event;
	return btn;
}
struct BUTTON make_button_draw8(handle_t win, int x, int y, int width, int height, int *event, char *text, int fcol) {
	struct BUTTON btn;
	btn = make_button8(x, y, width, height, event, text);
	btn.fcol = fcol;
	button_draw8(win, &btn, 0);
	return btn;
}
void button_draw8(const handle_t win, const struct BUTTON *btn, char selected) {
	btn->draw(win, btn, selected);
}
void link_draw8(handle_t win, struct BUTTON *btn) {
	api_boxfilwin(win, btn->x, btn->y+btn->height-2, btn->x+btn->width, btn->y+btn->height, COL8_000084);
	api_putstrwin(win, btn->x+(btn->width/3)-3, btn->y+(btn->height/3)-2, COL8_000084,
	strlen(btn->text), btn->text);
	return;
}
int wait(int i, int timer) {
	int j;
	if (i > 0) {
		/*等待一段时间*/
		api_settimer(timer, i);
		i = 128;
	} else {
		i = 0x0a; /* Enter */
	}
	for (;;) {
		j = api_getkey(1);
		if (i == j) {
			break;
		}
	}
	return j;
}
void button_allupdate(handle_t *win) {
	clicked = api_is_leftclicked(*win);
	if (!clicked)
		return;
	mx = api_get_wmx(*win);
	my = api_get_wmy(*win);
	return;
}
void button_pressed(handle_t win, struct BUTTON *btn) {
	btn->clicked = 1;
	btn->event(btn);
	return;
}
void button_update(handle_t win, struct BUTTON *btn) {
	char pointed = mx > (btn->x) && mx < (btn->x+btn->width) && my > (btn->y) && my < (btn->y+btn->height);
	if (!btn->enabled || !(mx > (btn->x-10) && mx < (btn->x+btn->width+10) && my > (btn->y-10) && my < (btn->y+btn->height+10)))
		return;
	if (clicked && pointed) {
		btn->pressed_draw(win, btn);
	}
	else if (!clicked) {
		btn->draw(win, btn, 0);
	}
	if (clicked && !btn->clicked && pointed) {
		button_pressed(win, btn);
	}
	else if (!clicked)
		btn->clicked = 0;
	return;
}
void link_update(handle_t win, struct BUTTON *btn) {
	
	if (clicked && !btn->clicked && mx > (btn->x) && mx < (btn->x+btn->width) && my > (btn->y) && my < (btn->y+btn->height)) {
		btn->clicked = 1;
		btn->event(btn);
	}
	else if (!clicked)
		btn->clicked = 0;
	return;
}
void make_gagebar8(handle_t win, int x, int y, int percentage) {
	x += 50;
	api_boxfilwin(win, x-51, y-1, x+101, y+31, COL8_000000);
	api_boxfilwin(win, x-50, y, x+100, y+30, COL8_FFFFFF);
	char *text;
	sprintf(text, "%d%%", percentage);
	int i;
	for (i = 0; i < percentage; i++) {
		api_boxfilwin(win, x-50, y, (int)(x+(i/2)), y+30, 4);
	}
	if (percentage >= 50)
		api_putstrwin(win, x, y+10, COL8_FFFFFF, strlen(text), text);
	else
		api_putstrwin(win, x, y+10, COL8_000000, strlen(text), text);
}
void textbox_input(int win, int x, int y, int sx, int sy, int col) {
	char *text = "";
	int i = 0;
	for (;;) {
		int key = api_getkey(1);
		if (key == 0x08 && i > 0) {
			text[--i] = 0;
		}
		else {
			text[i] = (char)key;
			text[i+1] = 0;
			i++;
		}
		api_boxfilwin(win, x+3, y, x+sx+2, y+sy, col);
		int buf;
		int _y = y;
		int _x = x;
		for (buf = 0; buf < i; buf++) {
			char c = text[buf];
			if (c == 0x0a) {
				_y += 18;
				_x = x;
			}
			else {
				char *s = &c;
				s[1] = 0;
				_x += 8;
				api_putstrwin(win, _x, _y, COL8_000000, strlen(s), s);
			}
		}
	}
}

int printf(char *format, ...)
{
	va_list ap;
	char s[1000];
	int i;

	va_start(ap, format);
	i = vsprintf(s, format, ap);
	api_putstr0(s);
	va_end(ap);
	return i;
}
int scanf(char * str, ...)
{
    va_list vl;
    int i = 0, j=0, ret = 0;
    char buff[100] = {0}, tmp[20], c;
    char *out_loc;
    while(c != 0) 
    {
		c = api_getkey(1);
        if (c != 0) 
        {
 	       buff[i] = c;
 	       i++;
 	    }
 	}
 	va_start( vl, str );
 	i = 0;
 	while (str && str[i])
 	{
 	    if (str[i] == '%') 
 	    {
 	       i++;
 	       switch (str[i]) 
 	       {
 	           case 'c': 
 	           {
	 	           *(char *)va_arg( vl, char* ) = buff[j];
	 	           j++;
	 	           ret ++;
	 	           break;
 	           }
 	           case 'd': 
 	           {
	 	           *(int *)va_arg( vl, int* ) =strtol(&buff[j], &out_loc, 10);
	 	           j+=out_loc -&buff[j];
	 	           ret++;
	 	           break;
 	            }
 	            case 'x': 
 	            {
	 	           *(int *)va_arg( vl, int* ) =strtol(&buff[j], &out_loc, 16);
	 	           j+=out_loc -&buff[j];
	 	           ret++;
	 	           break;
 	            }
 	        }
 	    } 
 	    else 
 	    {
 	        buff[j] =str[i];
            j++;
        }
        i++;
    }
    va_end(vl);
    return ret;
}

void *malloc(int size)
{
	char *p = api_malloc(size + 16);
	if (p != 0) {
		*((int *) p) = size;
		p += 16;
	}
	return p;
}

void free(void *p)
{
	char *q = p;
	int size;
	if (q != 0) {
		q -= 16;
		size = *((int *) q);
		api_free(q, size + 16);
	}
	return;
}
