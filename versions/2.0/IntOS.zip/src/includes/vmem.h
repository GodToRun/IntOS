#include "apilib.h"
#include <stdio.h>
#include <string.h>
#include <stdlibs.h>
char _vmem[100000];
size_t _vmem_top = 0;
char *vmem_malloc(size_t size) {
	char *buf = &_vmem[_vmem_top];
	int i;
	for (i = 0; i < size; i++) {
		buf[i] = 0;
	}
	_vmem_top += size;
	return buf;
}
void vmem_free(size_t size) {
	char *buf = &_vmem[_vmem_top];
	int i;
	for (i = 0; i < size; i++) {
		buf[i] = 0;
	}
	_vmem_top -= size;
	return;
}