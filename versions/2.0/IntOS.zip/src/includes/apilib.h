#ifndef NKERNEL_RESOURCE
#define API_RESOURCE_OS_NAME 0
#define API_RESOURCE_OS_VER 1
#endif

void api_putchar(int c);
void api_putstr0(char *s);
void api_putstr1(char *s, int l);
void api_end(void);
int api_openwin(char *buf, int xsiz, int ysiz, int col_inv, char *title);
void api_putstrwin(int win, int x, int y, int col, int len, char *str);
void api_boxfilwin(int win, int x0, int y0, int x1, int y1, int col);
void api_initmalloc(void);
char *api_malloc(int size);
void api_free(char *addr, int size);
void api_point(int win, int x, int y, int col);
void api_refreshwin(int win, int x0, int y0, int x1, int y1);
void api_linewin(int win, int x0, int y0, int x1, int y1, int col);
void api_closewin(int win);
int api_getkey(int mode);
int api_alloctimer(void);
void api_inittimer(int timer, int data);
void api_settimer(int timer, int time);
void api_freetimer(int timer);
void api_beep(int tone);
int api_fopen(char *fname);
void api_fclose(int fhandle);
void api_fseek(int fhandle, int offset, int mode);
int api_fsize(int fhandle, int mode);
int api_fread(char *buf, int maxsize, int fhandle);
int api_cmdline(char *buf, int maxsize);
int api_getlang(void);
int api_putcolchar(char c, int fcol, int bcol);
int api_putcolstr(char *s, int fcol, int bcol);
int api_dir_get(char *buf, int file_index);
int api_openiconwin(char bitmap_icon16[16][16], char *buf, int xsiz, int ysiz, int col_inv, char *title);
int api_opendialog(char *buf, int xsiz, int ysiz, int col_inv, char *title);
int api_decode_color(int c);
int api_get_mx(void);
int api_get_my(void);
int api_get_wmx(int win);
int api_get_wmy(int win);
int api_is_leftclicked(int win);
int api_isactive(int win);
int api_exec(char *name);
int api_start(void);
int api_scrnx(void);
int api_scrny(void);
int api_allocsheet(int flags);
int api_winlist(int number);
void api_set_config(int number, int data);
int api_winlist_top(void);
void api_system(char *command);
int api_rightclicked(void);
void api_setbuf_sheet(int win, char *buf, int width, int height, int col_inv);
void api_sheetslide(int win, int x, int y);
void api_sheetupdown(int win, int height);
void api_reboot(void);