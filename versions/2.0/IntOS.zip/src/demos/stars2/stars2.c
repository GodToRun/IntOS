#include "apilib.h"

int rand(void);		/*产生0～32767的随机数*/

void HariMain(void)
{
	char buf[200 * 150];
	int win, i, x, y;
	win = api_openwin(buf, 200, 150, -1, "Stars 2 Demo");
	api_boxfilwin(win + 1,  6, 26, 193, 143, 0);/*黑色*/
	for (i = 0; i < 120; i++) {
		x = (rand() % 291) +  6;
		y = (rand() %  143) + 26;
		api_point(win + 1, x, y, 3);/*黄色*/
	}
	api_refreshwin(win,  6, 26, 194, 144);
	for (;;) {
		if (api_getkey(1) == 0x0a) {
			break; /*按下回车键则break; */
		}
	}
	api_end();
}
