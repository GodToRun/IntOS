#include "apilib.h"
#include "stdlibs.h"
#include <stdio.h>
void test(void) {
	printf("HELLO WORLD");
}
void HariMain(void)
{
	char buf[300 * 500];
	handle_t win;
	win = api_openwin(buf, 300, 500, -1, "Widgets Demo");
	make_textbox8(win, 10, 30, 150, 50, COL8_FFFFFF);
	make_status_bar8(win, 10, 140, 100, 20, "status bar");
	make_gagebar8(win, 10, 100, 100, 25, 60);
	//textbox_input(win, 8, 33, 145, 45, COL8_FFFFFF);
	struct BUTTON chkbox = make_checkbox8(20, 220, "Check Box");
	struct BUTTON btn = make_button8(15, 440, 85, 30, NULL, "disabled");
	btn.enabled = 0;
	struct BUTTON btn2 = make_button8(120, 440, 60, 30, test, "test");
	selected_btn = &btn2;
	button_draw8(win, &btn, 0);
	button_draw8(win, &btn2, 1);
	button_draw8(win, &chkbox, 0);
	int timer = api_alloctimer();
	api_inittimer(timer, 128);
	struct LISTBOX box = make_listbox8(20, 280, 120, 100);
	struct BUTTON apple_item = listbox_add(&box, "Apple");
	listbox_add(&box, "Banana");
	listbox_add(&box, "Strawberry");
	listbox_add(&box, "Kiwi");
	listbox_add(&box, "Blueberry");
	listbox_draw8(win, &box);
	char text[30] = "Selected Item: ";
	listbox_select(&box, &apple_item);
	make_area8(win, 5, 200, 285, 290, "Widgets");
	for (;;) {
		wait(5, timer);
		widget_allupdate(&win);
		button_update(win, &btn);
		button_update(win, &chkbox);
		button_update(win, &btn2);
		listbox_update(win, &box);
		sprintf(text, "Selected Item: %s", box.selected_item->text);
		api_boxfilwin(win, 15, 405, 240, 425, LIGHTGRAY);
		api_putstrwin(win, 20, 410, BLACK, strlen(text), text);
	}
	api_end();
}