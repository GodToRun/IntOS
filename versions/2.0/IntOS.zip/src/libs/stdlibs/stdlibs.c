#include "apilib.h"
#include "stdlibs.h"

#include <stdio.h>
#include <stdarg.h>
#include <string.h>

struct BUTTON *selected_btn = NULL;
int mx = 0, my = 0, clicked = 0, is_active = 0;
void blank(void) { }
void chkbox_click(struct BUTTON *btn) {
	btn->tag = !btn->tag;
	return;
}
void drawchkbox(handle_t win, struct BUTTON *btn, ...) {
	static char icon[11][11] = {
		"...........",
		"...........",
		".........**",
		"........***",
		".......***.",
		"......***..",
		".....***...",
		"**..***....",
		"******.....",
		".****......",
		"..***......"
	};
	make_textbox8(win, btn->x, btn->y, btn->width, btn->height, WHITE);
	if (btn->tag) {
		//api_putstrwin(win, btn->x+2, btn->y, BLACK, 1, "v");
		draw_bitmap(win, 11, 11, icon, btn->x+1, btn->y, 1);
	}
	api_putstrwin(win, btn->x+22, btn->y-1, BLACK, strlen(btn->text), btn->text);
	return;
}
struct BUTTON make_checkbox8(int x, int y, char *text) {
	struct BUTTON btn = make_button8(x, y, 12, 12, chkbox_click, text);
	btn.tag = 0;
	btn.draw = drawchkbox;
	btn.pressed_draw = drawchkbox;
	return btn;
}
int putchar(int c)
{
	api_putchar(c);
	return c;
}
int getchar() {
	return api_getkey(1);
}

void exit(int status)
{
	api_end();
}
void make_textbox8(int win, int x0, int y0, int sx, int sy, int c)
{
	int x1 = x0 + sx, y1 = y0 + sy;
	api_boxfilwin(win, x0 - 2, y0 - 3, x1 + 1, y0 - 3, COL8_848484);
	api_boxfilwin(win, x0 - 3, y0 - 3, x0 - 3, y1 + 1, COL8_848484);
	api_boxfilwin(win, x0 - 3, y1 + 2, x1 + 1, y1 + 2, COL8_FFFFFF);
	api_boxfilwin(win, x1 + 2, y0 - 3, x1 + 2, y1 + 2, COL8_FFFFFF);
	api_boxfilwin(win, x0 - 1, y0 - 2, x1 + 0, y0 - 2, COL8_000000);
	api_boxfilwin(win, x0 - 2, y0 - 2, x0 - 2, y1 + 0, COL8_000000);
	api_boxfilwin(win, x0 - 2, y1 + 1, x1 + 0, y1 + 1, COL8_C6C6C6);
	api_boxfilwin(win, x1 + 1, y0 - 2, x1 + 1, y1 + 1, COL8_C6C6C6);
	api_boxfilwin(win,           x0 - 1, y0 - 1, x1 + 0, y1 + 0, c);
	return;
}
void make_status_bar8(int win, int x0, int y0, int sx, int sy, char *status)
{
	int x1 = x0 + sx, y1 = y0 + sy;
	api_boxfilwin(win, x0 - 2, y0 - 3, x1 + 1, y0 - 3, COL8_848484);
	api_boxfilwin(win, x0 - 3, y0 - 3, x0 - 3, y1 + 1, COL8_848484);
	api_boxfilwin(win, x0 - 3, y1 + 2, x1 + 1, y1 + 2, COL8_FFFFFF);
	api_boxfilwin(win, x1 + 2, y0 - 3, x1 + 2, y1 + 2, COL8_FFFFFF);
	//api_boxfilwin(win, x0 - 1, y0 - 2, x1 + 0, y0 - 2, COL8_000000);
	//api_boxfilwin(win, x0 - 2, y0 - 2, x0 - 2, y1 + 0, COL8_000000);
	api_boxfilwin(win, x0 - 2, y1 + 1, x1 + 0, y1 + 1, COL8_C6C6C6);
	api_boxfilwin(win, x1 + 1, y0 - 2, x1 + 1, y1 + 1, COL8_C6C6C6);
	api_boxfilwin(win,           x0 - 1, y0 - 1, x1 + 0, y1 + 0, COL8_C6C6C6);
	api_putstrwin(win, x0, y0 + 3, COL8_000000, strlen(status), status);
	return;
} 
char *puts(char *str) {
	api_putstr0(str);
	putchar('\n');
}
int fopen(const char *fileName, const char *fileMode) {
	return api_fopen(fileName);
}
int fclose(int file) {
	api_fclose(file);
	return 0;
}
char *fgets(char *str, int num, int stream) {
	int i;
	for (i = 0; i < num; i++) {
		if (api_fread(&str[i], 1, stream) == 0) {
			break;
		}
		str[i+1] = 0;
	}
	return str;
}
void draw_bitmap(int win, int xsize, int ysize, char bitmap[xsize][ysize], int bx, int by, int width) {
	int x, y, i;
	for (y = 0; y < ysize; y++) {
		for (x = 0; x < xsize; x++) {
			for (i = 0; i < width; i++) {
				if (bitmap[y][x] == '.') {
					continue;
				}
				else {
					api_point(win, bx + x + i, by + y + i, api_decode_color((int)bitmap[y][x]));
				}
			}
		}
	}
}
void button_drawprs(const handle_t win, const struct BUTTON *btn) {
	api_boxfilwin(win, btn->x, btn->y, btn->x+btn->width, btn->y+btn->height, COL8_000000);
	api_boxfilwin(win, btn->x+1, btn->y+1, btn->x+btn->width-1, btn->y+btn->height-1, DARKGRAY);
	api_boxfilwin(win, btn->x+2, btn->y+2, btn->x+btn->width-2, btn->y+btn->height-2, COL8_C6C6C6);
	api_putstrwin(win, btn->x+((btn->width-(strlen(btn->text)*4))/3)+2, btn->y+(btn->height/3)-1, btn->fcol,
	strlen(btn->text), btn->text);
}
void draw_rect(handle_t win, int x, int y, int x1, int y1, int col) {
	api_linewin(win, x, y, x1, y, col);
	api_linewin(win, x, y, x, y1, col);
	api_linewin(win, x1, y, x1, y1, col);
	api_linewin(win, x, y1, x1, y1, col);
}
void button_drawbtn(const handle_t win, const struct BUTTON *btn, char selected) {
	//Button
	int x = btn->x;
	int y = btn->y;
	int width = x+btn->width;
	int height = y+btn->height;
	
	if (selected) {
		api_linewin(win, x+1, y+1, width-2, y+1, WHITE);
		api_linewin(win, x+1, y+1, x+1, height-2, WHITE);
		
		api_linewin(win, x+2, height-2, width-2, height-2, DARKGRAY);
		api_linewin(win, width-2, y+2, width-2, height-2, DARKGRAY);

		api_linewin(win, x, height, width, height, BLACK);
		api_linewin(win, width, y, width, height, BLACK);

		draw_rect(win, x, y, width-1, height-1, BLACK);

		api_boxfilwin(win, x+2, y+2, width-3, height-3,LIGHTGRAY);
	}
	else {
		api_linewin(win, x, y, width-1, y, WHITE);
		api_linewin(win, x, y, x, height-1, WHITE);

		api_linewin(win, x+1, height-1, width-1, height-1, DARKGRAY);
		api_linewin(win, width-1, y+1, width-1, height-1, DARKGRAY);

		api_linewin(win, x, height, width, height, BLACK);
		api_linewin(win, width, y, width, height, BLACK);

		api_boxfilwin(win, x+1, y+1, width-2, height-2,LIGHTGRAY);
	}
	// Text
	if (btn->enabled != 0)
		api_putstrwin(win, btn->x+((btn->width-(strlen(btn->text)*4))/3)-1, btn->y+(btn->height/3)-2, btn->fcol,
		strlen(btn->text), btn->text);
	else {
		api_putstrwin(win, btn->x+((btn->width-(strlen(btn->text)*4))/3)-2, btn->y+(btn->height/3)-1, COL8_FFFFFF,
		strlen(btn->text), btn->text);
		api_putstrwin(win, btn->x+((btn->width-(strlen(btn->text)*4))/3)-1, btn->y+(btn->height/3)-2, COL8_848484,
		strlen(btn->text), btn->text);
	}
	return;
}
struct BUTTON make_button8(int x, int y, int width, int height, int *event, char *text) {
	api_initmalloc();
	struct BUTTON btn;
	btn.x = x;
	btn.text = text;
	btn.enabled = !0;
	btn.pointed_draw = blank;
	btn.fcol = COL8_000000;
	btn.y = y;
	btn.width = width;
	btn.height = height;
	btn.clicked = 0;
	btn.clicking = 0;
	btn.pointed = 0;
	btn.drawed = 0;
	btn.pressed_drawed = 0;
	btn.draw = button_drawbtn;
	btn.pressed_draw = button_drawprs;
	btn.event = event;
	return btn;
}
struct LISTBOX make_listbox8(int x, int y, int width, int height) {
	struct LISTBOX box;
	box.size = 0;
	box.selected_item = 0;
	box.x = x;
	box.y = y;
	box.width = width;
	box.enabled = 1;
	box.height = height;
	return box;
}
void listbox_select(struct LISTBOX *box, struct BUTTON *item) {
	box->selected_item = item;
	return;
}
void listbox_drwlstbox(handle_t win, struct BUTTON *btn, char selected) {
		api_boxfilwin(win, btn->x, btn->y, btn->x+btn->width, btn->y+btn->height, WHITE);
		api_putstrwin(win, btn->x+5, btn->y+4, BLACK, strlen(btn->text), btn->text);
}
void listbox_drwlstboxprs(handle_t win, struct BUTTON *btn) {
		api_boxfilwin(win, btn->x, btn->y, btn->x+btn->width, btn->y+btn->height, DARKBLUE);
		api_putstrwin(win, btn->x+5, btn->y+4, WHITE, strlen(btn->text), btn->text);
}
void listbox_update(handle_t win, struct LISTBOX *box) {
	int i;
	for (i = 0; i < box->size; i++) {
		button_update(win, &box->items[i]);
		if (box->items[i].clicking) {
			box->selected_item = &box->items[i];
		}
	}
}
void listbox_update_isact(handle_t win, struct LISTBOX *box, int isact) {
	if (!box->enabled)
		return;
	int i;
	for (i = 0; i < box->size; i++) {
		if (&box->items[i] == selected_btn)
			selected_btn = NULL;
		button_update_isact(win, &box->items[i], isact);
		if (box->items[i].clicking) {
			box->selected_item = &box->items[i];
			
		}
	}
	
}
struct BUTTON listbox_add(struct LISTBOX *box, char *name) {
	struct BUTTON btn = make_button8(box->x, box->y+(box->size*20), box->width, 20, blank, name);
	btn.draw = listbox_drwlstbox;
	btn.pressed_draw = listbox_drwlstboxprs;
	box->items[box->size] = btn;
	box->size++;
	return btn;
}
void listbox_draw8(handle_t win, struct LISTBOX *listbox) {
	listbox_drawfunc(win, listbox->x, listbox->y,
	listbox->width, listbox->height, make_textbox8);
	listbox_button_draw8(win, listbox);
}
void listbox_drawfunc(handle_t win, int x, int y, int width, int height, void (*func)()) {
	func(win, x, y,
	width, height, WHITE);
}
void listbox_button_draw8(handle_t win, struct LISTBOX *listbox) {
	int i;
	for (i = 0; i < listbox->size; i++) {
		button_draw8(win, &listbox->items[i], 0);
	}
}
struct BUTTON make_button_draw8(handle_t win, int x, int y, int width, int height, int *event, char *text, int fcol) {
	struct BUTTON btn;
	btn = make_button8(x, y, width, height, event, text);
	btn.fcol = fcol;
	button_draw8(win, &btn, 0);
	return btn;
}
void button_draw8(const handle_t win, const struct BUTTON *btn, char selected) {
	if (btn == NULL)
		return;
	if (selected == -1)
		selected = 0;
	else {
		if (selected_btn == btn)
			selected = 1;
		else
			selected = 0;
	}
	btn->draw(win, btn, selected);
}
void link_draw8(handle_t win, struct BUTTON *btn) {
	api_boxfilwin(win, btn->x, btn->y+btn->height-2, btn->x+btn->width, btn->y+btn->height, COL8_000084);
	api_putstrwin(win, btn->x+(btn->width/3)-3, btn->y+(btn->height/3)-2, COL8_000084,
	strlen(btn->text), btn->text);
	return;
}
int wait(int i, int timer) {
	int j;
	if (i > 0) {
		/*等待一段时间*/
		api_settimer(timer, i);
		i = 128;
	} else {
		i = 0x0a; /* Enter */
	}
	for (;;) {
		j = api_getkey(1);
		if (i == j) {
			break;
		}
	}
	return j;
}
void widget_allupdate(handle_t *win) {
	clicked = api_is_leftclicked(*win);
	//if (!clicked)
	//	return;
	mx = api_get_wmx(*win);
	my = api_get_wmy(*win);
	if (!clicked)
		return;
	is_active = api_isactive(*win);
	return;
}
void button_pressed(handle_t win, struct BUTTON *btn) {
	btn->clicked = 1;
	btn->event(btn);
	if (win != NULL && btn != selected_btn)
		button_draw8(win, selected_btn, -1);
	selected_btn = btn;
	return;
}
void make_area8(int win, int x, int y, int width, int height, char *text) {
	api_putstrwin(win, x + 3, y - 20, COL8_000000, strlen(text), text);
	api_linewin(win, x, y, x+width, y, DARKGRAY);
	api_linewin(win, x, y, x, y+height, DARKGRAY);
	api_linewin(win, x, y+height, x+width, y+height, DARKGRAY);
	api_linewin(win, x+width, y, x+width, y+height, DARKGRAY);
	api_linewin(win, x+1, y+1, x+width+1, y+1, WHITE);
	api_linewin(win, x+1, y+1, x+1, y+height+1, WHITE);
	api_linewin(win, x+1, y+1+height, x+width+1, y+height+1, WHITE);
	api_linewin(win, x+1+width, y+1, x+width+1, y+height+1, WHITE);
}
void button_update_isact(handle_t win, struct BUTTON *btn, int isact) {
	if (!isact)
		return;
	char pointed = mx > (btn->x) && mx < (btn->x+btn->width) && my > (btn->y) && my < (btn->y+btn->height);
	if (!btn->enabled) return;
		if (pointed && !btn->pointed) {
			btn->pointed_draw(win, btn);
			btn->pointed = 1;
		}
		else if (!pointed && btn->pointed && btn->pointed_draw != blank) {
			button_draw8(win, btn, 0);
			btn->pointed = 0;
		}
	else if (clicked && pointed && !btn->pressed_drawed) {
		btn->clicking = 1;
		btn->pressed_draw(win, btn);
		btn->drawed = 0;
		btn->pressed_drawed = 1;
	}
	else if (!clicked && !btn->drawed) {
		btn->clicking = 0;
		button_draw8(win, btn, 0);
		btn->drawed = 1;
		btn->pressed_drawed = 0;
	}
	if (clicked && !btn->clicked && pointed) {
		button_pressed(win, btn);
	}
	else if (!clicked)
		btn->clicked = 0;
	else if (!btn->clicking) {
		btn->drawed = 1;
	}
	return;
}
void button_update(handle_t win, struct BUTTON *btn) {
	button_update_isact(win, btn, is_active);
	return;
}
void make_gagebar8(handle_t win, int x, int y, int width, int height, int percentage) {
	make_status_bar8(win, x, y, width, height, "\0");
	int i;
	for (i = 0; i < (int)(percentage/10); i++) {
		api_boxfilwin(win, x+i*13, y, x+i*13+10, y+height-2, DARKBLUE);
	}
}
char *textbox_input(int win, int x, int y, int sx, int sy, int col, int breakkey) {
	char text[100] = {0};
	int i = 0;
	for (;;) {
		int key = api_getkey(1);
		if (key == breakkey)
			return text;
		if (key == 0x08 && i >= 0) {
			text[--i] = 0;
		}
		else {
			text[i] = (char)key;
			i++;
		}
		api_boxfilwin(win, x+3, y, x+sx+2, y+sy, col);
		int buf;
		int _y = y;
		int _x = x;
		for (buf = 0; buf < i; buf++) {
			char c = text[buf];
			if (c == 0x0a) {
				_y += 18;
				_x = x;
			}
			else {
				char s[2] = {0};
				s[0] = c;
				_x += 8;
				api_putstrwin(win, _x, _y, COL8_000000, strlen(s), s);
			}
		}
	}
}

int printf(char *format, ...)
{
	va_list ap;
	char s[1000];
	int i;

	va_start(ap, format);
	i = vsprintf(s, format, ap);
	api_putstr0(s);
	va_end(ap);
	return i;
}

void *malloc(int size)
{
	char *p = api_malloc(size + 16);
	if (p != 0) {
		*((int *) p) = size;
		p += 16;
	}
	return p;
}

void free(void *p)
{
	char *q = p;
	int size;
	if (q != 0) {
		q -= 16;
		size = *((int *) q);
		api_free(q, size + 16);
	}
	return;
}