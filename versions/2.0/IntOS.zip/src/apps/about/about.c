#include <string.h>
#include "apilib.h"
#include <stdlibs.h>
void HariMain(void)
{
	char buf[300 * 200];
	int win, i;
	char cmdline[20], *filename;
	api_cmdline(cmdline, 20);
	filename = &cmdline[6];
	char title[20];
	sprintf(title, "About %s", filename);
	win = api_openwin(buf, 300, 200, -1, title);
	struct BUTTON close = make_button8(220, 160, 70, 25, api_end, "Close");
	api_putstrwin(win, 20, 40, BLACK, strlen(title), title);
	api_putstrwin(win, 20, 80, BLACK, strlen("Copyright (C) RunToRun"), "Copyright (C) RunToRun");
	api_putstrwin(win, 20, 120, BLACK, strlen("All Rights Reserved."), "All Rights Reserved.");
	int timer = api_alloctimer();
	api_inittimer(timer, 128);
	selected_btn = &close;
	button_draw8(win, &close, 1);
	for (;;) {
		wait(5, timer);
		widget_allupdate(&win);
		button_update(win, &close);
	}	
	api_end();
}
