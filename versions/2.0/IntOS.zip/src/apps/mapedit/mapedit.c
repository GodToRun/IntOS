#include "apilib.h"
#include "stdlibs.h"
#include <stdio.h>
char map[16][16];
extern int mx, my, clicked, is_active;
int rclicked = 0;
void HariMain(void)
{
	char buf[400 * 350];
	int win;
	win = api_openwin(buf, 400, 350, -1, "Bitmap Editor");
	make_textbox8(win, 300, 53, 80, 160, WHITE);
	make_textbox8(win, 300, 224, 80, 80, WHITE);
	api_putstrwin(win, 310, 60, BLACK, 5, "BTN1=");
	api_putstrwin(win, 310, 80, BLACK, 5, "BLACK");
	api_putstrwin(win, 310, 120, BLACK, 5, "BTN2=");
	api_putstrwin(win, 310, 140, BLACK, 5, "WHITE");
	char c;
	int i, j;
	for (i = 0; i < 16; i++) {
		for (j = 0; j < 16; j++) {
			map[j][i] = '.';
			draw_bitbutton(win, 30+(i*16), 50+(j*16), 16, 16, WHITE);
		}
	}
	int timer = api_alloctimer();
	api_inittimer(timer, 128);
	for (;;) {
		wait(1, timer);
		widget_allupdate(&win);
		if (!is_active)
			continue;
		rclicked = api_rightclicked();
		for (i = 0; i < 16; i++) {
			for (j = 0; j < 16; j++) {
				c = bitupdate(win, 30+(i*16), 50+(j*16), 16, 16);
				if (c == 1) {
					map[j][i] = '*';
					refresh(win);
				}
				else if (c == 2) {
					map[j][i] = 'O';
					refresh(win);
				}
			}
		}
	}
	api_end();
}
void draw_bitbutton(int win, int x, int y, int width, int height, int col) {
	width += x, height += y;
	api_boxfilwin(win, x, y, width, height, BLACK);
	api_boxfilwin(win, x+1, y+1, width-1, height-1, col);
}
char bitupdate(int win, int x, int y, int width, int height) {
	if (mx > x && mx < x+width && my > y && my < y+height) {
		if (clicked) {
			api_boxfilwin(win, x+1, y+1, x+width-1, y+height-1, BLACK);
			return 1;
		}
		else if (rclicked) {
			api_boxfilwin(win, x+1, y+1, x+width-1, y+height-1, WHITE);
			return 2;
		}
		
	}
	return 0;
}
void refresh(int win) {
	api_boxfilwin(win, 310, 234, 60, 60, WHITE);
	draw_bitmap(win, 16, 16, map, 328, 258, 1);
}