#include "apilib.h"
#include <stdlibs.h>
#include <string.h>
#include <stdio.h>

void HariMain(void)
{
	char buf[310 * 340];
	handle_t win = api_openwin(buf, 310, 340, -1, "Character Map");
	int x = 13;
	int y = 30;
	int i;
	for (i = 0x21; i < 0x85; i++) {
		draw_frame(win, x, y, i);
		x += 30;
		if (x > 300) {
			x = 13;
			y += 30;
		}
	}
	api_getkey(1);
	api_closewin(win);
	api_end();
}
void draw_frame(handle_t handle, int x, int y, char c) {
	char buf[2];
	buf[0] = c;
	buf[1] = 0;
	make_status_bar8(handle, x, y, 9, 19, buf);
}