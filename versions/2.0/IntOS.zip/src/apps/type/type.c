#include "apilib.h"
#include "stdlibs.h"
#define EOF 0

void HariMain(void)
{
	int fh;
	char c, cmdline[30], *p;
	api_cmdline(cmdline, 30);
	for (p = cmdline; *p > ' '; p++) { }	/*跳过之前的内容，直到遇到空格*/
	for (; *p == ' '; p++) { }	/*跳过空格*/
	fh = api_fopen(p);
	if (fh != 0) {
		for (;;) {
			if (api_fread(&c, 1, fh) == EOF) {
				break;
			}
			putchar(c);
		}
	} else {
		api_putstr0("File not found.\n");
	}
	api_fclose(fh);
	api_end();
}
