#include "apilib.h"
#include "stdlibs.h"
#include <stdio.h>
#include <string.h>

int win;
struct LISTBOX picker;
struct LISTBOX box;
void event_apply(void) {
	int c = picker.selected_item->tag;
	api_set_config(box.selected_item->tag, c);
	api_end();
}
void HariMain(void)
{
	char buf[300 * 400];
	win = api_openwin(buf, 300, 400, -1, "Int OS Configuration");
	box = make_listbox8(10, 30, 280, 140);
	picker = make_listbox8(10, 180, 280, 140);
	struct BUTTON apply = make_button8(230, 350, 60, 30, event_apply, "Apply");
	listbox_add(&box, "Active Window");
	listbox_add(&box, "Disable Window");
	listbox_add(&box, "Window");
	listbox_add(&box, "Console Text Color");
	box.items[0].tag = 0;
	box.items[1].tag = 2;
	box.items[2].tag = 1;
	box.items[3].tag = 3;
	listbox_add(&picker, "Light Gray");
	listbox_add(&picker, "Gray");
	listbox_add(&picker, "White");
	listbox_add(&picker, "Blue");
	listbox_add(&picker, "Dark Blue");
	listbox_add(&picker, "Red");
	picker.items[0].tag = LIGHTGRAY;
	picker.items[1].tag = DARKGRAY;
	picker.items[2].tag = WHITE;
	picker.items[3].tag = BLUE;
	picker.items[4].tag = DARKBLUE;
	picker.items[5].tag = RED;
	int timer = api_alloctimer();
	api_inittimer(timer, 128);
	listbox_draw8(win, &box);
	listbox_draw8(win, &picker);
	button_draw8(win, &apply, 0);
	for (;;) {
		wait(5, timer);
		widget_allupdate(&win);
		listbox_update(win, &box);
		listbox_update(win, &picker);
		button_update(win, &apply);
	}
	api_end();
}
