#include "apilib.h"
#include <stdio.h>
#include <string.h>
#include <stdlibs.h>
#include <vmem.h>
#define GET_PARAM 1
#define SHELL_ADDR 0x1414 //sht_back address
int param_win;
struct BUTTON tasks[10];
int task_size = 0;
struct LISTBOX box;
struct BUTTON start;
char start_clicked = 0;
void invader_start(void) {
	api_exec("invader");
}
void paint_start(void) {
	api_exec("paint");
}
void init_start(void) {
	api_exec("init");
}
void taskmgr_start(void) {
	api_exec("taskmgr");
}
extern void blank(void);
void select(struct BUTTON *sender) {

}
void start_process(int win, char *name) {
	if (task_size > 7)
		return;
	int len = strlen(name);
	if (len > 9) {
		name[10] = 0;
		name[9] = '.';
		name[8] = '.';
		name[7] = '.';
	}
	tasks[task_size] = make_button8(100+(task_size*108), api_scrny() - 24, 100, 20, select, name);
	button_draw8(SHELL_ADDR, &tasks[task_size], 0);
	tasks[task_size].tag = win;
	task_size++;
}
void btn_draw(handle_t win, struct BUTTON *btn, ...) {
	api_boxfilwin(win, btn->x, btn->y, btn->x+btn->width+1, btn->y+btn->height+1, LIGHTGRAY);
}
void ldisable(void) {
	int i;
	for (i = 0; i < box.size; i++) {
		box.items[i].enabled = 0;
	}
}
void lenable(void) {
	int i;
	for (i = 0; i < box.size; i++) {
		box.items[i].enabled = 1;
	}
}
void make_startmenu(int win, int x0, int y0, int sx, int sy, int c) {
	int width = x0 + sx;
	int height = y0 + sy;
	api_boxfilwin(win, x0 - 1, y0 - 2, width, height, LIGHTGRAY);
	api_boxfilwin(win, x0 - 21, y0 - 2, x0 - 1, height, DARKGRAY);
	api_boxfilwin(win, width+1, y0 - 2, width+1, height, DARKGRAY);
	api_boxfilwin(win, width+2, y0 - 2, width+2, height, BLACK);
	api_boxfilwin(win, x0, y0 + 30, width, y0 + 30, WHITE);
	api_boxfilwin(win, x0, y0 + 29, width, y0 + 29, DARKGRAY);
	api_boxfilwin(win, x0, height - 30, width, height - 30, WHITE);
	api_boxfilwin(win, x0, height - 29, width, height - 29, DARKGRAY);
	api_boxfilwin(win, x0 - 21, height-1, width+1, height-1, DARKGRAY);
	api_boxfilwin(win, x0 - 21, height, width+1, height, BLACK);
	api_boxfilwin(win, x0 - 22, y0 - 2, width+1, y0 - 2, WHITE);
	api_boxfilwin(win, x0 - 21, y0 - 1, width+1, y0 - 1, LIGHTGRAY);
	api_boxfilwin(win, x0 - 22, y0 - 1, x0 - 22, height, WHITE);
	api_boxfilwin(win, x0 - 21, y0 - 1, x0 - 21, height-1, LIGHTGRAY);
}
void ldraw(void) {
	
	if (!start_clicked) {
		listbox_drawfunc(SHELL_ADDR, box.x, box.y, box.width, box.height, make_startmenu);
		listbox_button_draw8(SHELL_ADDR, &box);
		lenable();
	}
	else {
		ldisable();
		draw_empty(SHELL_ADDR, &box);
	}
	start_clicked = !start_clicked;
}
void draw_empty(handle_t win, struct LISTBOX *btn) {
	api_boxfilwin(win, btn->x-23, btn->y-5, btn->x+btn->width+2, btn->y+btn->height, CYAN);
}

char *open_getparam() {
	char *buf = vmem_malloc(250 * 100);
	param_win = api_opendialog(buf, 250, 100, -1, "Get Parameters");
	make_textbox8(param_win, 50, 45, 150, 30, WHITE);
	char *text = textbox_input(param_win, 50, 45, 150, 30, WHITE, 0x0a);
	api_closewin(param_win);
	vmem_free(250 * 100);
	return text;
}
void exec(struct BUTTON *sender) {
	start_clicked = 0;
	ldisable();
	if (sender->tag == GET_PARAM) {
		draw_empty(SHELL_ADDR, &box);
		start_draw(SHELL_ADDR, &start, 0);
		api_exec(open_getparam());
		return;
	}
	else cmpexec(sender->text);
	draw_empty(SHELL_ADDR, &box);
	start_draw(SHELL_ADDR, &start, 0);
	return;
}
void button_drawprs(handle_t win, struct BUTTON *btn);
void button_drawbtn(handle_t win, struct BUTTON *btn, char selected);
void start_draw(handle_t win, struct BUTTON *btn, ...) {
	if (start_clicked) {
		bitbtn_drawprs(win, btn);
	}
	else {
		bitbtn_draw(win, btn);
	}
}
void bitbtn_draw(handle_t win, struct BUTTON *btn, ...) {
		button_drawbtn(win, btn, 0);
		draw_bitmap(win, 16, 16, (char **)btn->tag, btn->x+3, btn->y+2, 1);
}
void bitbtn_drawprs(handle_t win, struct BUTTON *btn) {
		button_drawprs(win, btn);
		draw_bitmap(win, 16, 16, (char **)btn->tag, btn->x+5, btn->y+4, 1);
}
void start_drawbtn(handle_t win, struct BUTTON *btn, char selected) {
		api_boxfilwin(win, btn->x, btn->y, btn->x+btn->width, btn->y+btn->height, LIGHTGRAY);
		api_putstrwin(win, btn->x+5, btn->y+4, BLACK, strlen(btn->text), btn->text);
}
void cmpexec(char *text) {
	if (strcmp(text, "Command Prompt") == 0) {
		api_start();
	}
	else if (strcmp(text, "Welcome") == 0) {
		api_exec("init");
	}
	else if (strcmp(text, "Task Manager") == 0) {
		api_exec("taskmgr");
	}
	else if (strcmp(text, "Bitmap Editor") == 0) {
		api_exec("mapedit");
	}
	else if (strcmp(text, "Shut Down...") == 0) {
		api_exec("shutdown");
	}
	else api_exec(text);
}
void main(void)
{
	static char os_icon[16][16] = {
		"OOOOOOOOOOOOOOOO",
		"O**************O",
		"OOOOOOO**OOOOOOO",
		"......O**O......",
		"......O**O......",
		"......O**O......",
		"......O**O......",
		"......O**O......",
		"......O**O......",
		"......O**O......",
		"......O**O......",
		"......O**O......",
		"OOOOOOO**OOOOOOO",
		"O**************O",
		"OOOOOOOOOOOOOOOO"
	};
	int timer = api_alloctimer();
	api_inittimer(timer, 128);
	box = make_listbox8(22, api_scrny() - 289, 125, 260);
	start = make_button8(3, api_scrny() - 24, 80, 20, ldraw, "Start");
	start.draw = start_draw;
	start.pressed_draw = bitbtn_drawprs;
	start.tag = (int)os_icon;
	button_draw8(SHELL_ADDR, &start, 0);
	listbox_add(&box, "About IntOS");
	listbox_add(&box, "Welcome");
	listbox_add(&box, "Command Prompt");
	listbox_add(&box, "Invader");
	listbox_add(&box, "Bitmap Editor");
	listbox_add(&box, "Task Manager");
	listbox_add(&box, "Paint");
	listbox_add(&box, "Config");
	listbox_add(&box, "Tedit");
	listbox_add(&box, "Tview");
	listbox_add(&box, "Gview");
	listbox_add(&box, "Shut Down...");
	box.items[box.size-3].tag = GET_PARAM;
	box.items[box.size-2].tag = GET_PARAM;
	ldisable();
	char text[20];
	int win = SHELL_ADDR;
	int i = 0, j;
	for (i = 0; i < box.size; i++) {
		if (i != 0 && i != 10 && i != 9)
			box.items[i].y += 18;
		box.items[i].event = exec;
		box.items[i].draw = start_drawbtn;
		box.items[i].pointed_draw = box.items[i].pressed_draw;
	}
	int top;
	int sht;
	
	for (;;) {
		wait(5, timer);
		widget_allupdate(&win);
		button_update_isact(SHELL_ADDR, &start, 1);
		listbox_update_isact(SHELL_ADDR, &box, 1);
		for (i = 0; i < task_size; i++) {
			button_update_isact(SHELL_ADDR, &tasks[i], 1);
		}
		top = api_winlist_top();
		if (top > task_size+1) {
			sht = api_winlist(task_size);
			start_process(sht, "Window");
		}
		else if (top < task_size+1) {
			end_process();
		}
	}
	api_end();
}
void end_process() {
	btn_draw(SHELL_ADDR, &tasks[task_size-1]);
	task_size--;
}