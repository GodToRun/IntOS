#include "apilib.h"
#include <stdlibs.h>
#include <stdio.h>
#include "string.h"
struct LISTBOX box;
int win, timer;
char vram[100000];
size_t vram_top = 0;
void end_task(void) {
	if (box.selected_item->tag == win) {
		printf("Cannot end own task");
		putchar('\n');
	}
	else
		api_closewin(box.selected_item->tag);
}
void run_task(void) {
	char *buf = tmalloc(150 * 200);
	int i;
	int dialog = api_opendialog(buf, 200, 150, -1, "Run");
	make_textbox8(dialog, 15, 40, 100, 20, COL8_FFFFFF);
	char *text = textbox_input(dialog, 15, 40, 100, 20, COL8_FFFFFF, 0x0a);
	api_exec(text);
	api_end();
}
char *tmalloc(size_t size) {
	char *buf = &vram[vram_top];
	int i;
	for (i = 0; i < size; i++) {
		buf[i] = 0;
	}
	vram_top += size;
	return buf;
}
void HariMain(void)
{
	char buf[250 * 420];
	win = api_openwin(buf, 250, 420, -1, "Task Manager");
	make_textbox8(win, 8, 30, 232, 340, COL8_FFFFFF);
	int i;
	char cmdline[30];
	int sht;
	box = make_listbox8(8, 30, 232, 340);
	struct BUTTON end = make_button8(150, 380, 90, 30, end_task, "End Task");
	struct BUTTON run = make_button8(8, 380, 90, 30, run_task, "Run Task");
	
	for (i = 0; i < 256; i++) {
		sht = api_winlist(i);
		char *s = tmalloc(30);
		if (sht == -1)
			continue;
		sprintf(cmdline, "PID %p", sht);
		//api_putstrwin(win, 15, (i*20)+40, COL8_000000, strlen(cmdline), cmdline);
		strcpy(s, cmdline);
		listbox_add(&box, s);
		box.items[box.size-1].tag = sht;
	}
	button_draw8(win, &end, 0);
	button_draw8(win, &run, 0);
	listbox_draw8(win, &box);
	timer = api_alloctimer();
	api_inittimer(timer, 128);
	for (;;) {
		wait(5, timer);
		widget_allupdate(&win);
		button_update(win, &end);
		button_update(win, &run);
		listbox_update(win, &box);
	}
	api_end();
	return;
}