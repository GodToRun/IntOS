#include "apilib.h"
#include "stdlibs.h"
int layer;
void closew(void) {
	api_reboot();
	api_end();
}
void HariMain(void)
{
	int scrnx = api_scrnx();
	int scrny = api_scrny();
	api_initmalloc();
	char *lbuf = api_malloc(scrnx * scrny);
	layer = api_openwin(lbuf, scrnx, scrny, 255, "Screen Saver");
	api_boxfilwin(layer, 0, 0, scrnx, scrny, 255);
	//api_sheetupdown(layer, 1);
	int i = 0;
	int j;
	int k = 0;
	for (j = 0; j < scrny; j += 1) {
		for (; i < scrnx; i += 2) {
			api_point(layer, i, j, BLACK);
		}
		i = k;
		k = !k;
	}
	api_sheetslide(layer, 0, 0);
	int win;
	char buf[300 * 100];
	win = api_openwin(buf, 300, 100, -1, "Shutdown IntOS");
	struct BUTTON shutdown = make_button8(20, 60, 100, 30, 0, "Shutdown");
	shutdown.enabled = 0; //Shutdown System not implemented.
	struct BUTTON close = make_button8(130, 60, 80, 30, closew, "Reboot");
	selected_btn = &shutdown;
	button_draw8(win, &shutdown, 0);
	struct BUTTON *btn = &shutdown;
	api_putstrwin(win, btn->x+((btn->width-(strlen(btn->text)*4))/3)-2, btn->y+(btn->height/3)-1, COL8_FFFFFF,
		strlen(btn->text), btn->text);
	api_putstrwin(win, btn->x+((btn->width-(strlen(btn->text)*4))/3)-1, btn->y+(btn->height/3)-2, COL8_848484,
		strlen(btn->text), btn->text);
	button_draw8(win, &close, 0);
	api_putstrwin(win, 20, 30, BLACK, strlen("Are you sure you want to:"), "Are you sure you want to:");
	int timer = api_alloctimer();
	api_inittimer(timer, 128);
	for (;;) {
		wait(5, timer);
		widget_allupdate(&win);
		button_update(win, &close);
	}
	api_end();
}
