#include "apilib.h"
#include <stdlibs.h>
#include <string.h>
#include <stdio.h>
handle_t win;
struct BUTTON btn, btn2;
char buf[200 * 300];
int floor = 0;
char floort[20];
int tick = 0;
void mktxtbox(void) {
	make_textbox8(win, 20, 40, 160, 210, COL8_FFFFFF);
}
int trand(void) {
	return tick;
}
void left(void) {
	int num = pollup();
	if (num == 0) {
		floor++;
		showinfo();
	}
	else {
		gameover();
	}
}
int pollup(void) {
	return trand();
}
void right(void) {
	tick++;
		if (tick > 1)
			tick = 0;
	int num = pollup();
	if (num == 0) {
		floor++;
		showinfo();
	}
	else {
		gameover();
	}
}
void showinfo() {
	sprintf(floort, "Floor(s): %d", floor);
	mktxtbox();
	api_putstrwin(win, 30, 40, BLACK, strlen(floort), floort);
}
void gameover() {
	btn.enabled = 0;
	btn2.enabled = 0;
	btn.draw(win, &btn, 0);
	btn2.draw(win, &btn2, 0);
}
void HariMain(void)
{
	win = api_openwin(buf, 200, 300, -1, "Floor Climb");
	btn = make_button8(20, 265, 60, 22, left, "left");
	btn2 = make_button8(110, 265, 60, 22, right, "right");
	sprintf(floort, "Floor(s): %d", floor);
	mktxtbox();
	showinfo();
	button_draw8(win, &btn, 0);
	button_draw8(win, &btn2, 0);
	int timer = api_alloctimer();
	api_inittimer(timer, 128);
	for (;;) {
		wait(5, timer);
		tick++;
		if (tick > 1)
			tick = 0;
		widget_allupdate(&win);
		button_update(win, &btn);
		button_update(win, &btn2);
	}
	api_closewin(win);
	api_end();
}