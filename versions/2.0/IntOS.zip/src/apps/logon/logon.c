#include <string.h>
#include "apilib.h"
#include <stdlibs.h>
int win, timer;
void logon(void) {
	api_logon();
	api_exec("shell");
	api_end();
}
void HariMain(void)
{
	api_initmalloc();
	char buf[310 * 150];
	int i, x, y;
	win = api_opendialog(buf, 310, 150, -1, "Log in to Int OS");
	struct BUTTON ok = make_button8(222, 110, 70, 25, logon, "Log on");
	api_putstrwin(win, 28, 52, BLACK, strlen("Login to Int OS Network"), "Login to Int OS Network");
	selected_btn = &ok;
	button_draw8(win, &ok, 1);
	timer = api_alloctimer();
	api_inittimer(timer, 128);
	for (;;) {
		wait(5, timer);
		widget_allupdate(&win);
		button_update(win, &ok);
	}	
	api_closewin(win);
	api_end();
}