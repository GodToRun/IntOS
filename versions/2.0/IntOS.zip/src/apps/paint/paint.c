#include "apilib.h"
#include <stdlibs.h>
#include <string.h>
#include <stdio.h>
handle_t win;
char buf[400 * 300];
int cur_c = 0;
void set_color_black(void) {
	cur_c = COL8_000000;
}
void set_color_white(void) {
	cur_c = COL8_FFFFFF;
}
void set_color_red(void) {
	cur_c = 1;
}
void set_color_blue(void) {
	cur_c = BLUE;
}
void mktxtbox(void) {
	make_textbox8(win, 20, 40, 270, 210, COL8_FFFFFF);
}
void draw_white_btn(const handle_t win, const struct BUTTON *sender) {
	make_textbox8(win, sender->x, sender->y, sender->width, sender->height, COL8_FFFFFF);
	draw_palatte();
}
void draw_black_btn(const handle_t win, const struct BUTTON *sender) {
	make_textbox8(win, sender->x, sender->y, sender->width, sender->height, COL8_000000);
	draw_palatte();
}
void draw_red_btn(const handle_t win, const struct BUTTON *sender) {
	make_textbox8(win, sender->x, sender->y, sender->width, sender->height, 1);
	draw_palatte();
}
void draw_blue_btn(const handle_t win, const struct BUTTON *sender) {
	make_textbox8(win, sender->x, sender->y, sender->width, sender->height, BLUE);
	draw_palatte();
}
void draw_palatte(void) {
	make_textbox8(win, 20, 260, 30, 30, COL8_FFFFFF);
	api_boxfilwin(win, 24, 264, 46, 286, COL8_000000);
	api_boxfilwin(win, 25, 265, 45, 285, cur_c);
}
void HariMain(void)
{
	win = api_openwin(buf, 400, 300, -1, "Int OS Paint");
	struct BUTTON btn = make_button8(70, 265, 20, 20, set_color_black, "black");
	struct BUTTON btn2 = make_button8(100, 265, 20, 20, set_color_white, "white");
	struct BUTTON btny = make_button8(130, 265, 20, 20, set_color_red, "red");
	struct BUTTON btn4 = make_button8(160, 265, 20, 20, set_color_blue, "blue");
	struct BUTTON btn3 = make_button8(305, 40, 80, 30, mktxtbox, "clear");
	struct BUTTON exit = make_button8(305, 230, 80, 30, api_end, "exit");
	btn2.draw = draw_white_btn;
	btn2.pressed_draw = draw_white_btn;
	btn.draw = draw_black_btn;
	btn.pressed_draw = draw_black_btn;
	btny.draw = draw_red_btn;
	btny.pressed_draw = draw_red_btn;
	btn4.draw = draw_blue_btn;
	btn4.pressed_draw = draw_blue_btn;
	mktxtbox();
	button_draw8(win, &btn, 0);
	button_draw8(win, &btn2, 0);
	button_draw8(win, &btn3, 0);
	button_draw8(win, &btny, 0);
	button_draw8(win, &btn4, 0);
	button_draw8(win, &exit, 0);
	int timer = api_alloctimer();
	api_inittimer(timer, 128);
	extern int clicked;
	for (;;) {
		wait(5, timer);
		widget_allupdate(&win);
		if (clicked) {
			if (!api_isactive(win))
				continue;
			int wmx, wmy;
			wmx = api_get_wmx(win);
			wmy = api_get_wmy(win);
			if (wmx > 20 && wmy > 40 && wmx < 290 && wmy < 250) {
				draw_point(win, wmx, wmy);
			}
		}
		button_update(win, &btn);
		button_update(win, &btn2);
		button_update(win, &btn3);
		button_update(win, &btny);
		button_update(win, &btn4);
		button_update(win, &exit);
	}
	api_closewin(win);
	api_end();
}
void draw_point(handle_t win, int wmx, int wmy) {
	api_boxfilwin(win, wmx, wmy, wmx+1, wmy+1, cur_c);
}